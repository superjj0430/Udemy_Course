DFS Python
==============


非递归

.. literalinclude:: ../_code/9-graph-traversal/dfs.py
   :language: python
   :linenos:

递归

.. literalinclude:: ../_code/9-graph-traversal/dfs-recursion.py
   :language: python
   :linenos:
