BFS Python
==============


.. literalinclude:: ../_code/9-graph-traversal/bfs.py
   :language: python
   :linenos:
