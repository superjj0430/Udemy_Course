# O(n)


def bigo(n):
    for i in range(n):
        print(i)
        for j in range(n):
            print(j)


bigo(10)

# O(n^2)

# O(1)

a = [1, 2, 3]

a[0]
