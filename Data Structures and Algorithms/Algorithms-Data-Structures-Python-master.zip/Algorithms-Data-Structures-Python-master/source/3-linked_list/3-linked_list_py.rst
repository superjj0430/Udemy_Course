Linked List in Python
==========================



Singly Linked List
------------------

.. literalinclude:: ../_code/3-linked_list/linked_list.py
   :language: python
   :linenos:

Doubly Linked List
------------------

.. literalinclude:: ../_code/3-linked_list/doubly_linked_list.py
   :language: python
   :linenos: