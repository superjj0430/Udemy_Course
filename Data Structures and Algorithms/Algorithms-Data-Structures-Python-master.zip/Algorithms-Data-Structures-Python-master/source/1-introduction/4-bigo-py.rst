BIG O and Python
========================

.. literalinclude:: ../_code/1-introduction/bigo.py
   :language: python
   :linenos:
