用Python实现一个Graph
==========================


基于邻接列表的存储方式，用Python实现一个Graph，要求实现初始化，添加删除节点和边。

.. literalinclude:: ../_code/7-graph/graph.py
   :language: python
   :linenos: