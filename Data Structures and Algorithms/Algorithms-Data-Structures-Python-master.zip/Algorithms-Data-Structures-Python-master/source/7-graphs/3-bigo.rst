BIG O 分析
===================

.. image:: ../_static/7-graph/bigo.PNG
   :width: 900px