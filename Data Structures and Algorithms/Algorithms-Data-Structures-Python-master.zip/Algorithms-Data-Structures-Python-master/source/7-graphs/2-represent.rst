图的表示
=================

Adjacency Matrix
-----------------------

邻接矩阵

.. image:: ../_static/7-graph/tree-matrix.PNG
   :width: 700px

Adjacency List
-----------------------

邻接列表

.. image:: ../_static/7-graph/adjacency_list.jpg
   :width: 700px


.. image:: ../_static/7-graph/tree-present.PNG
   :width: 700px