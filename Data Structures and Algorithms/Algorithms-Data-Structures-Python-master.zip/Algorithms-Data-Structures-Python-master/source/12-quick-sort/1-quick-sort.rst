Quick Sort 快排
=====================

Quick Sort的Python实现

.. literalinclude:: ../_code/12-quick-sort/quick-sort.py
   :language: python
   :linenos:
