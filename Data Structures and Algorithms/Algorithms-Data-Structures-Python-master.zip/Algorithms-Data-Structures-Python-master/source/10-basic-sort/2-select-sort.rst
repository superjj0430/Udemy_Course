Select Sort
=============



选择排序的Python实现

.. literalinclude:: ../_code/10-basic-sort/selection-sort.py
   :language: python
   :linenos:
