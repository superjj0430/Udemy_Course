Bubble Sort 冒泡排序
=======================


https://en.wikipedia.org/wiki/Bubble_sort


冒泡排序的Python实现

.. literalinclude:: ../_code/10-basic-sort/bubble-sort.py
   :language: python
   :linenos:
