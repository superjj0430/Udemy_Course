Insert Sort
=======================

插入排序的Python实现

.. literalinclude:: ../_code/10-basic-sort/insertion-sort.py
   :language: python
   :linenos:
