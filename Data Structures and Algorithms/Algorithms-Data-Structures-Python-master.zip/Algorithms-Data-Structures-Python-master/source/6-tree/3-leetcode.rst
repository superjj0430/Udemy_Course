LeetCode 练习
================

Search in a Binary Search Tree
---------------------------------

https://leetcode.com/problems/search-in-a-binary-search-tree/description/


Solution


.. literalinclude:: ../_code/6-tree/leetcode-search-bst.py
   :language: python
   :linenos:
