Breadth First Search的实现
=================================

.. image:: ../_static/6-tree/bfs-py.PNG
   :width: 700px

.. literalinclude:: ../_code/8-tree-traversal/bfs.py
   :language: python
   :linenos:
