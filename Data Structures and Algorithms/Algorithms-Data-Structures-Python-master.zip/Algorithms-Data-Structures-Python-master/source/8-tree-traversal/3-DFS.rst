Depth First Search的实现
=================================


.. literalinclude:: ../_code/8-tree-traversal/dfs.py
   :language: python
   :linenos:
