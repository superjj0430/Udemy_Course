Practise
===============


Implement Stack using Queues
-------------------------------

https://leetcode.com/problems/implement-stack-using-queues/


Implement Queue using Stacks
---------------------------------

https://leetcode.com/problems/implement-queue-using-stacks/


Min Stack
--------------

https://leetcode.com/problems/min-stack/
