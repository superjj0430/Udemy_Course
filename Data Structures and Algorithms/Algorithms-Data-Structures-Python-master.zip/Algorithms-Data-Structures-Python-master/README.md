# Algorithms-Data-Structures-Python

此文档是本人正在制作的一门在线视频课程的配套文件，供参考，课程购买链接https://algorithms-data-structures-python.readthedocs.io/en/latest/
